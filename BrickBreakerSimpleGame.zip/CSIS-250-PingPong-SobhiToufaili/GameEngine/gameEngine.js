

var wait;
var bricks = [];
var destroyedBricks = [];

class game {
  constructor(canvasWidth, canvasHeight) {
    this.canvas = document.getElementById("mainGame");
    if (this.canvas.getContext) {
      this.ctx = this.canvas.getContext("2d");
    }
    this.score = 0;
    this.gameOver = false;
    this.sprites = [];
    this.cw = canvasWidth;
    this.ch = canvasHeight;
  }
  addSprite(sprite) {
    this.sprites.push(sprite);
  }
  update() {
    var lSpritesLength = this.sprites.length;
    for (var i = 0; i < lSpritesLength; i++)
    {

      if(this.sprites[i] != null)
      {
          this.sprites[i].update();
      }
      if(this.sprites[i] instanceof rectangle && this.sprites[i].isDestroyed())
      {
        this.score++;
        removeElement(this.sprites, this.sprites[i]);
      }
    }
    
  }

  draw() {
    var lSpritesLength = this.sprites.length;
    for (var i = 0; i < lSpritesLength; i++) {
      this.sprites[i].draw(this.ctx);
    }
      this.ctx.font = "20px Sans Serif";
      this.ctx.fillStyle = "white";
      this.ctx.fillText("Score:" + this.score, 10, 15);
      if(this.sprites.length == 3)
      {
      this.ctx.font = "50px Sans Serif";
      this.ctx.fillStyle = "white";
      this.ctx.fillText("Congrats! You won.", 100, 150);
        throw 'exit';
      }
    }
};
class Sprite {
  constructor() {
  }
  update() {
  }
  draw(pCtx) {
  }
}
window.requestAnimFrame = (function (callback) {
  return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
    function (callback) {
      window.setTimeout(callback, 1000 / 60);
    };
})();



var keysDown = {};
addEventListener("keydown", function (e) { // to record user's input
  keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) { // to record user's input
  delete keysDown[e.keyCode];
}, false);

function removeElement(array, element) { // removes a element from a array using splice method
  for (let i = 0; i < array.length; i++) {
    if (array[i] == element) array.splice(i, 1);
  }
}
class ball extends Sprite {
  constructor(x, y, r, color, rectPlayer) {
      super(); this.x = x; this.y = y; this.r = r; this.color = color; this.rectPlayer = rectPlayer; this.deflectY = 2; this.deflectX = -2; // intial x and y of object ball
  }

  fill(color) // fills the ball with the color the user wants
  {
      this.color = color;
  }

  draw(ctx) // draws the circle with the spcified x, y and color
  {
      ctx.beginPath();
      ctx.fillStyle = this.color;
      ctx.arc(this.x, this.y, this.r, 0, 2 * Math.PI);
      ctx.lineWidth = 1;
      ctx.fill()
      ctx.stroke();
      if(this.y > 770)
      {
          ctx.font = "50px Sans Serif";
          ctx.fillStyle = "white";
          ctx.fillText("Ball out of Bound! You lost", 20, 300);
          throw 'exit';
      }
  }

  update() // this method updates the objects coordintes according to the input of the user
  {

      if ((this.x < 20 || this.x > 580)) {
        this.deflectX = -this.deflectX;
      }

      if (((this.y > 650 && this.y < 660) && (this.x < this.rectPlayer.getX() + 80 && this.x > this.rectPlayer.getX()) ) || this.y < 5) {
        this.deflectY = -this.deflectY;
      }

      this.x += this.deflectX;
      this.y += this.deflectY;

      
  }
  getX() {
      return this.x;
  }
  getY() {
      return this.y;
  }
}
class rectangle extends Sprite {
  constructor(x, y, w, h, color, isBrick) // a constructor to create a rectangle object with specified parameters
  {
      super();
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
      this.color = color;
      this.isBrick = isBrick;
      this.isdestroyed = false;
  }
  isDestroyed()
  {
      return this.isdestroyed;
  }
  fill(color) // fills the rectangle with the color the user wants
  {
      this.color = color;
  }
  addPlayer(ballPlayer) {
      this.ballPlayer = ballPlayer;
  }

  draw(ctx) // draws the rectangle with the spcified x, y and color
  {
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.rect(this.x, this.y, this.w, this.h);
      ctx.fillRect(this.x, this.y, this.w, this.h);
  }

  update() {

      if (this.isBrick == false) {
          if (37 in keysDown) { // Player holding up
              if (this.x > 1) {
                  this.x -= 3;
              }
          }

          if (39 in keysDown) { // Player holding down
              if (this.x < 515) {
                  this.x += 3;
              }
          }
      } else if (this.isBrick == true) {

          if (this.ballPlayer.getX() + 5 < this.x + this.w && this.ballPlayer.getX() + 5 > this.x || this.ballPlayer.getX() - 5  < this.x + this.w && this.ballPlayer.getX() - 5 > this.x) {
              if (this.ballPlayer.getY() + this.ballPlayer.r  > this.y && this.ballPlayer.getY() + this.ballPlayer.r < (this.y + this.h) || this.ballPlayer.getY() - this.ballPlayer.r > this.y && this.ballPlayer.getY() - this.ballPlayer.r < (this.y + this.h)) {
          {
              this.ballPlayer.deflectX = this.ballPlayer.deflectX;
              this.ballPlayer.deflectY = -this.ballPlayer.deflectY;
              this.isdestroyed = true;
          }
      }
      }
  }
  }
  getX() {
      return this.x;
  }
  getY() {
      return this.y;
  }
}

class DrawImage extends Sprite {
  constructor(x, y, w, h, img) {
      super();
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
      this.img = img;
  }
  update() {

  }
  draw(ctx) {
      ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
  }
}


function animate(myGame) { // a recursive fucntion that updates and draws the sprites.
  if (39 in keysDown || 37 in keysDown)
    wait = true;
  if(wait) 
    myGame.update();

    myGame.draw();
  requestAnimFrame(function () {
    animate(myGame);
  });
}

