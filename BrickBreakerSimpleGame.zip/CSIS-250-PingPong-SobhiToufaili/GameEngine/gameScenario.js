

function GameScenario(myGame) { // this method is intialized first, it intializes all the sprites the game needs and calls the recursive function animate.
    var bgimg = new Image();
    bgimg.src = 'images/table.png';
    var bgImg = new DrawImage(0, 0, 600, 800, bgimg);
    var player = new rectangle(270, 660, 80, 10, '#3498DB', false);
    var ballPlayer = new ball(310, 650, 10, "red", player);
  
    player.addPlayer(ballPlayer);
    ballPlayer.fill("#D68910")
    myGame.addSprite(bgImg);
    myGame.addSprite(player);
    myGame.addSprite(ballPlayer);
    var offsetX = 0;
    var offsetY = 0;
    for (i = 0; i < 16; i++) {
      if (i % 4 == 0) {
        offsetY += 60;
        offsetX = 0;
        var brick = new rectangle(offsetX + 30, 5 + offsetY, 120, 40, '#900C3F', true);
      }
      else {
        var brick = new rectangle(offsetX + 30, 5 + offsetY, 120, 40, '#900C3F', true);
      }
      brick.addPlayer(ballPlayer);
      bricks.push(brick);
      myGame.addSprite(brick);
      offsetX += 140;
    }
    animate(myGame);
  };
  

BrickBreaker = new game(800, 1000);
GameScenario(BrickBreaker); // starting the game